# Save.gd — автозагрузка (singleton). Хранит прогресс между запусками игры.
# Файл сохранения: user://hoopflight_save.json
extends Node

const PATH := "user://hoopflight_save.json"

var data := {
	"coins": 0,              # накопленные очки-валюта
	"total_hoops": 0,        # всего пройдено колец за всё время
	"owned": ["classic"],    # купленные/выданные скины
	"skin": "classic",       # выбранный скин
	"best": {},              # лучший счёт по режимам
	"best_hoops": {},        # лучшее число колец по режимам
	"best_combo": 0,
	"runs": 0,
	"free_rank": 0,          # сколько бесплатных скинов уже выдано
	"ultra_reward": false,   # получен ли легендарный мяч
	"sound": true,
	"music": true,
}


func _ready() -> void:
	load_game()


func load_game() -> void:
	if not FileAccess.file_exists(PATH):
		return
	var f := FileAccess.open(PATH, FileAccess.READ)
	if f == null:
		return
	var parsed = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	for k in parsed.keys():
		if data.has(k):
			data[k] = parsed[k]
	# страховка: стартовый скин всегда доступен
	if not data["owned"].has("classic"):
		data["owned"].append("classic")


func save_game() -> void:
	var f := FileAccess.open(PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))
		f.close()


# --- удобные обёртки ---

func coins() -> int:
	return int(data["coins"])


func add_coins(n: int) -> void:
	data["coins"] = coins() + n


func spend(n: int) -> bool:
	if coins() < n:
		return false
	data["coins"] = coins() - n
	save_game()
	return true


func owns(skin_id: String) -> bool:
	return data["owned"].has(skin_id)


func unlock(skin_id: String) -> void:
	if not owns(skin_id):
		data["owned"].append(skin_id)
		save_game()


func select_skin(skin_id: String) -> void:
	if owns(skin_id):
		data["skin"] = skin_id
		save_game()


func current_skin() -> Dictionary:
	return Skins.by_id(String(data["skin"]))


func best_score(mode_id: String) -> int:
	return int(data["best"].get(mode_id, 0))


func best_hoops(mode_id: String) -> int:
	return int(data["best_hoops"].get(mode_id, 0))


# Итоги забега. Возвращает список новых наград (для показа игроку).
func finish_run(mode_id: String, score: int, hoops: int, best_combo: int) -> Array:
	var rewards: Array = []
	data["runs"] = int(data["runs"]) + 1
	add_coins(score)
	data["total_hoops"] = int(data["total_hoops"]) + hoops
	if score > best_score(mode_id):
		data["best"][mode_id] = score
	if hoops > best_hoops(mode_id):
		data["best_hoops"][mode_id] = hoops
	if best_combo > int(data["best_combo"]):
		data["best_combo"] = best_combo

	# бесплатные скины за общее число пройденных колец
	while int(data["free_rank"]) < Skins.FREE_THRESHOLDS.size() \
			and int(data["total_hoops"]) >= Skins.FREE_THRESHOLDS[int(data["free_rank"])]:
		var rank := int(data["free_rank"])
		for s in Skins.LIST:
			if int(s["free_rank"]) == rank:
				unlock(String(s["id"]))
				rewards.append("Достижение: %d колец — открыт мяч «%s»" % [Skins.FREE_THRESHOLDS[rank], s["name"]])
		data["free_rank"] = rank + 1

	save_game()
	return rewards


func grant_ultra_reward() -> bool:
	if bool(data["ultra_reward"]):
		return false
	data["ultra_reward"] = true
	unlock("legend")
	save_game()
	return true


func next_free_threshold() -> int:
	var r := int(data["free_rank"])
	if r >= Skins.FREE_THRESHOLDS.size():
		return -1
	return Skins.FREE_THRESHOLDS[r]
