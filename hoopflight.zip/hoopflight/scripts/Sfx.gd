# Sfx.gd — автозагрузка. Звуки и музыка.
# Все .wav сгенерированы кодом (см. tools/gen_audio.py), внешних файлов нет.
extends Node

const SFX_FILES := {
	"flap": "res://audio/flap.wav",
	"common": "res://audio/ring_common.wav",
	"rare": "res://audio/ring_rare.wav",
	"epic": "res://audio/ring_epic.wav",
	"legendary": "res://audio/ring_legendary.wav",
	"divine": "res://audio/ring_divine.wav",
	"fire": "res://audio/fire.wav",
	"burn": "res://audio/burn.wav",
	"hurt": "res://audio/hurt.wav",
	"gameover": "res://audio/gameover.wav",
	"buff": "res://audio/buff.wav",
	"achieve": "res://audio/achieve.wav",
	"click": "res://audio/click.wav",
	"buy": "res://audio/buy.wav",
}

const MUSIC_FILES := {
	"calm": "res://audio/music_calm.wav",
	"normal": "res://audio/music_normal.wav",
	"tense": "res://audio/music_tense.wav",
	"ultra": "res://audio/music_ultra.wav",
}

var _sfx: Dictionary = {}
var _players: Array[AudioStreamPlayer] = []
var _next := 0
var _music_player: AudioStreamPlayer
var _current_music := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for key in SFX_FILES.keys():
		if ResourceLoader.exists(SFX_FILES[key]):
			_sfx[key] = load(SFX_FILES[key])
	# пул плееров, чтобы звуки не обрывали друг друга
	for i in 10:
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		_players.append(p)
	_music_player = AudioStreamPlayer.new()
	_music_player.volume_db = -12.0
	add_child(_music_player)
	_music_player.finished.connect(_loop_music)


func play(key: String, volume_db: float = -6.0, pitch: float = 1.0) -> void:
	if not SaveData.data["sound"] or not _sfx.has(key):
		return
	var p := _players[_next]
	_next = (_next + 1) % _players.size()
	p.stream = _sfx[key]
	p.volume_db = volume_db
	p.pitch_scale = pitch
	p.play()


func play_music(key: String) -> void:
	if _current_music == key and _music_player.playing:
		return
	_current_music = key
	if not SaveData.data["music"] or not MUSIC_FILES.has(key):
		_music_player.stop()
		return
	if not ResourceLoader.exists(MUSIC_FILES[key]):
		return
	_music_player.stream = load(MUSIC_FILES[key])
	_music_player.play()


func stop_music() -> void:
	_current_music = ""
	_music_player.stop()


func _loop_music() -> void:
	if SaveData.data["music"] and _music_player.stream != null:
		_music_player.play()


func refresh_music() -> void:
	if not SaveData.data["music"]:
		_music_player.stop()
	elif _current_music != "":
		var k := _current_music
		_current_music = ""
		play_music(k)
