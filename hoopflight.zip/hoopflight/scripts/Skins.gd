# Skins.gd — все мячи игры и их пассивные способности.
# Чтобы добавить свой скин: допиши словарь в конец LIST.
class_name Skins
extends RefCounted

# ability — служебное имя способности, его читает Play.gd
# price = 0 -> либо стартовый, либо выдаётся за достижение (free_rank >= 0)
const LIST := [
	{
		"id": "classic", "name": "Классический", "desc": "Обычный красный мяч. Без способностей.",
		"price": 0, "free_rank": -1, "ability": "none",
		"main": Color(0.85, 0.33, 0.13), "line": Color(0.15, 0.09, 0.06), "glow": Color(0, 0, 0, 0),
	},
	{
		"id": "asbest", "name": "Асбестовый", "desc": "Иммунитет к огненным кольцам: край не отнимает жизнь.",
		"price": 500, "free_rank": -1, "ability": "fire_immune",
		"main": Color(0.55, 0.58, 0.62), "line": Color(0.15, 0.16, 0.18), "glow": Color(1.0, 0.45, 0.1, 0.35),
	},
	{
		"id": "feather", "name": "Пуховый", "desc": "После кольца 1 сек падает на 30% медленнее.",
		"price": 1200, "free_rank": -1, "ability": "slow_fall",
		"main": Color(0.95, 0.93, 0.85), "line": Color(0.55, 0.52, 0.45), "glow": Color(1, 1, 1, 0.25),
	},
	{
		"id": "wide", "name": "Точный", "desc": "Коридор прохода шире на 18% — попадать легче.",
		"price": 2500, "free_rank": -1, "ability": "wide_gate",
		"main": Color(0.20, 0.65, 0.45), "line": Color(0.05, 0.25, 0.18), "glow": Color(0.2, 1.0, 0.6, 0.25),
	},
	{
		"id": "magnet", "name": "Магнитный", "desc": "Шанс 30% получить +4 очка на обычном кольце.",
		"price": 4000, "free_rank": -1, "ability": "magnet",
		"main": Color(0.85, 0.20, 0.30), "line": Color(0.20, 0.05, 0.08), "glow": Color(1.0, 0.2, 0.4, 0.3),
	},
	{
		"id": "spring", "name": "Пружинный", "desc": "Импульс прыжка сильнее на 12%, управление мягче.",
		"price": 6000, "free_rank": -1, "ability": "strong_jump",
		"main": Color(0.95, 0.75, 0.15), "line": Color(0.35, 0.25, 0.05), "glow": Color(1.0, 0.9, 0.3, 0.3),
	},
	{
		"id": "heart", "name": "Живучий", "desc": "Даёт дополнительную 4-ю жизнь.",
		"price": 9000, "free_rank": -1, "ability": "extra_life",
		"main": Color(0.90, 0.35, 0.55), "line": Color(0.35, 0.10, 0.20), "glow": Color(1.0, 0.4, 0.6, 0.3),
	},
	{
		"id": "moon", "name": "Лунный", "desc": "Гравитация слабее на 15% — мяч спокойнее.",
		"price": 13000, "free_rank": -1, "ability": "low_gravity",
		"main": Color(0.70, 0.75, 0.95), "line": Color(0.25, 0.28, 0.45), "glow": Color(0.6, 0.7, 1.0, 0.35),
	},
	{
		"id": "angel", "name": "Ангельский", "desc": "Один раз за забег спасает от падения на землю.",
		"price": 18000, "free_rank": -1, "ability": "ground_save",
		"main": Color(1.0, 0.98, 0.90), "line": Color(0.75, 0.65, 0.35), "glow": Color(1.0, 0.95, 0.6, 0.45),
	},
	{
		"id": "storm", "name": "Штормовой", "desc": "Серийные бонусы включаются на 30% раньше.",
		"price": 25000, "free_rank": -1, "ability": "fast_combo",
		"main": Color(0.35, 0.45, 0.85), "line": Color(0.10, 0.15, 0.35), "glow": Color(0.4, 0.6, 1.0, 0.4),
	},
	{
		"id": "prime", "name": "Премиальный", "desc": "Коридор шире на 10% и +15% ко всем очкам.",
		"price": 40000, "free_rank": -1, "ability": "premium",
		"main": Color(0.55, 0.25, 0.85), "line": Color(0.20, 0.05, 0.35), "glow": Color(0.8, 0.4, 1.0, 0.45),
	},
	# --- бесплатные скины за достижения (по числу пройденных колец) ---
	{
		"id": "bronze", "name": "Бронзовый", "desc": "Награда за 500 колец. +5% очков.",
		"price": 0, "free_rank": 0, "ability": "bonus_points_small",
		"main": Color(0.72, 0.45, 0.20), "line": Color(0.30, 0.16, 0.06), "glow": Color(0.9, 0.6, 0.3, 0.3),
	},
	{
		"id": "silver", "name": "Серебряный", "desc": "Награда за 1500 колец. Коридор шире на 8%.",
		"price": 0, "free_rank": 1, "ability": "wide_gate_small",
		"main": Color(0.80, 0.83, 0.88), "line": Color(0.35, 0.38, 0.42), "glow": Color(0.9, 0.95, 1.0, 0.35),
	},
	{
		"id": "emerald", "name": "Изумрудный", "desc": "Награда за 4000 колец. Гравитация слабее на 8%.",
		"price": 0, "free_rank": 2, "ability": "low_gravity_small",
		"main": Color(0.15, 0.75, 0.45), "line": Color(0.03, 0.28, 0.16), "glow": Color(0.3, 1.0, 0.6, 0.4),
	},
	{
		"id": "ruby", "name": "Рубиновый", "desc": "Награда за 10000 колец. Шанс 20% на +6 очков.",
		"price": 0, "free_rank": 3, "ability": "magnet_big",
		"main": Color(0.90, 0.12, 0.25), "line": Color(0.32, 0.02, 0.08), "glow": Color(1.0, 0.2, 0.3, 0.45),
	},
	{
		"id": "cosmos", "name": "Космический", "desc": "Награда за 25000 колец. Иммунитет к огню + 10% очков.",
		"price": 0, "free_rank": 4, "ability": "cosmic",
		"main": Color(0.15, 0.10, 0.35), "line": Color(0.75, 0.80, 1.0), "glow": Color(0.5, 0.4, 1.0, 0.5),
	},
	# --- эксклюзив за Ультра Хардкор ---
	{
		"id": "legend", "name": "Легендарный", "desc": "25 колец подряд в Ультра Хардкоре. Не действуют никакие дебаффы.",
		"price": -1, "free_rank": -1, "ability": "legendary",
		"main": Color(1.0, 0.82, 0.25), "line": Color(0.45, 0.28, 0.02), "glow": Color(1.0, 0.85, 0.2, 0.6),
	},
]

# Пороги бесплатных скинов: каждый следующий примерно в 2.5 раза больше
const FREE_THRESHOLDS := [500, 1500, 4000, 10000, 25000]


static func count() -> int:
	return LIST.size()


static func by_id(id: String) -> Dictionary:
	for s in LIST:
		if s["id"] == id:
			return s
	return LIST[0]


static func index_of(id: String) -> int:
	for i in LIST.size():
		if LIST[i]["id"] == id:
			return i
	return 0


# Числовые параметры способности — их использует игровая логика
static func mods(ability: String) -> Dictionary:
	var m := {
		"fire_immune": false,
		"slow_fall": false,
		"gate_bonus": 0.0,      # + к размеру коридора (доля)
		"magnet_chance": 0.0,
		"magnet_points": 0,
		"jump_mult": 1.0,
		"extra_life": 0,
		"gravity_mult": 1.0,
		"ground_save": false,
		"combo_mult": 1.0,      # < 1 = серии срабатывают раньше
		"points_mult": 1.0,
	}
	match ability:
		"fire_immune": m["fire_immune"] = true
		"slow_fall": m["slow_fall"] = true
		"wide_gate": m["gate_bonus"] = 0.18
		"wide_gate_small": m["gate_bonus"] = 0.08
		"magnet":
			m["magnet_chance"] = 0.30
			m["magnet_points"] = 4
		"magnet_big":
			m["magnet_chance"] = 0.20
			m["magnet_points"] = 6
		"strong_jump": m["jump_mult"] = 1.12
		"extra_life": m["extra_life"] = 1
		"low_gravity": m["gravity_mult"] = 0.85
		"low_gravity_small": m["gravity_mult"] = 0.92
		"ground_save": m["ground_save"] = true
		"fast_combo": m["combo_mult"] = 0.7
		"premium":
			m["gate_bonus"] = 0.10
			m["points_mult"] = 1.15
		"bonus_points_small": m["points_mult"] = 1.05
		"cosmic":
			m["fire_immune"] = true
			m["points_mult"] = 1.10
		"legendary":
			m["fire_immune"] = true
			m["points_mult"] = 1.20
			m["gate_bonus"] = 0.12
			m["ground_save"] = true
	return m
