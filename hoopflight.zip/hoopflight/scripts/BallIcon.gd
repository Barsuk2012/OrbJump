# BallIcon.gd — маленький предпросмотр мяча для меню и магазина.
class_name BallIcon
extends Control

var skin: Dictionary = Skins.LIST[0]
var spin := 0.0


func _ready() -> void:
	custom_minimum_size = Vector2(96, 96)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process(true)


func _process(delta: float) -> void:
	spin += delta * 1.2
	queue_redraw()


func _draw() -> void:
	var c := size * 0.5
	var r: float = min(size.x, size.y) * 0.42
	var main: Color = skin.get("main", Color.RED)
	var line: Color = skin.get("line", Color.BLACK)
	var glow: Color = skin.get("glow", Color(0, 0, 0, 0))
	if glow.a > 0.02:
		draw_circle(c, r + 7.0, Color(glow.r, glow.g, glow.b, glow.a * 0.5))
	draw_circle(c, r, main)
	draw_circle(c - Vector2(r * 0.28, r * 0.3), r * 0.4, main.lightened(0.2))
	draw_arc(c, r, 0, TAU, 32, line, 2.0, true)
	draw_arc(c, r, spin, spin + PI, 18, line, 2.0, true)
	for k in 2:
		var a := spin + PI * 0.5 * k
		var pts := PackedVector2Array()
		for i in range(13):
			var f: float = float(i) / 12.0 * PI - PI * 0.5
			var local := Vector2(sin(f) * r, cos(f) * r * 0.42 * (1 if k == 0 else -1))
			pts.append(c + local.rotated(a))
		draw_polyline(pts, line, 1.8, true)
