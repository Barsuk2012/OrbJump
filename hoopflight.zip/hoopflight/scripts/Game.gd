# Game.gd — «мозг» игры: меню, магазин, статистика, HUD, пауза, экран проигрыша.
# Весь интерфейс собирается кодом, без .tscn-файлов.
extends Node2D

enum S { MENU, MODES, SHOP, STATS, PLAY, PAUSE, OVER }

var state: int = S.MENU
var play: Play
var ui: CanvasLayer
var screens := {}
var current_mode := "normal"

# элементы, которые обновляются на лету
var coin_labels: Array[Label] = []
var hud_score: Label
var hud_lives: Label
var hud_combo: Label
var hud_buffs: Label
var over_title: Label
var over_body: Label
var shop_box: VBoxContainer
var stats_body: Label
var reward_label: Label
var reward_t := 0.0

const BG := Color(0.09, 0.11, 0.16, 0.93)
const ACCENT := Color(1.0, 0.62, 0.15)


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	play = Play.new()
	play.name = "Play"
	play.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(play)
	play.game_over.connect(_on_game_over)
	play.reward.connect(_on_reward)

	ui = CanvasLayer.new()
	ui.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(ui)

	_build_menu()
	_build_modes()
	_build_shop()
	_build_stats()
	_build_hud()
	_build_pause()
	_build_over()

	_build_reward_label()
	_go(S.MENU)
	Sfx.play_music("calm")


func _process(delta: float) -> void:
	if state == S.PLAY:
		var st: Dictionary = play.hud_state()
		hud_score.text = "%d" % int(st["score"])
		hud_lives.text = "♥".repeat(int(st["lives"])) + "·".repeat(max(0, int(st["max_lives"]) - int(st["lives"])))
		hud_combo.text = ("СЕРИЯ %d" % int(st["combo"])) if int(st["combo"]) > 1 else ""
		var buffs: Array[String] = []
		if float(st["ghost"]) > 0.0:
			buffs.append("ПРИЗРАК %.1f" % float(st["ghost"]))
		if float(st["slowmo"]) > 0.0:
			buffs.append("ЗАМЕДЛЕНИЕ %.1f" % float(st["slowmo"]))
		if float(st["double"]) > 0.0:
			buffs.append("x2 %.1f" % float(st["double"]))
		if bool(st["shield"]):
			buffs.append("ЩИТ")
		hud_buffs.text = "   ".join(buffs)
		if not bool(st["started"]):
			hud_buffs.text = "Тапни по экрану / пробел — импульс вверх"
	if reward_t > 0.0:
		reward_t -= delta
		reward_label.visible = true
		reward_label.modulate.a = clamp(reward_t, 0.0, 1.0)
	else:
		reward_label.visible = false


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		if state == S.PLAY:
			_pause()
		elif state == S.PAUSE:
			_resume()


# ================= вспомогательные виджеты =================

func _screen() -> Control:
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(c)
	return c


func _dim(parent: Control, alpha := 0.86) -> ColorRect:
	var r := ColorRect.new()
	r.color = Color(0.06, 0.07, 0.11, alpha)
	r.set_anchors_preset(Control.PRESET_FULL_RECT)
	r.mouse_filter = Control.MOUSE_FILTER_STOP
	parent.add_child(r)
	return r


func _label(text: String, size: int, col := Color(1, 1, 1)) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _button(text: String, w := 420.0, h := 64.0, col := ACCENT) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(w, h)
	b.add_theme_font_size_override("font_size", 26)
	b.add_theme_color_override("font_color", Color(0.06, 0.06, 0.09))
	b.add_theme_color_override("font_hover_color", Color(0.06, 0.06, 0.09))
	b.add_theme_color_override("font_pressed_color", Color(0.2, 0.2, 0.2))
	var sb := StyleBoxFlat.new()
	sb.bg_color = col
	sb.set_corner_radius_all(14)
	sb.content_margin_left = 18
	sb.content_margin_right = 18
	var hov := sb.duplicate() as StyleBoxFlat
	hov.bg_color = col.lightened(0.15)
	var pres := sb.duplicate() as StyleBoxFlat
	pres.bg_color = col.darkened(0.2)
	b.add_theme_stylebox_override("normal", sb)
	b.add_theme_stylebox_override("hover", hov)
	b.add_theme_stylebox_override("pressed", pres)
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b.pressed.connect(func(): Sfx.play("click", -16.0))
	return b


func _vbox(parent: Control, sep := 14, top := 0.0) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", sep)
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.offset_top = top
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(v)
	return v


func _coin_label(parent: Control) -> Label:
	var l := _label("", 26, Color(1, 0.85, 0.35))
	l.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	l.position = Vector2(-320, 22)
	l.size = Vector2(290, 34)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	parent.add_child(l)
	coin_labels.append(l)
	return l


func _refresh_coins() -> void:
	for l in coin_labels:
		l.text = "Очки: %d" % SaveData.coins()


# ================= экраны =================

func _build_menu() -> void:
	var s := _screen()
	_dim(s, 0.35)
	screens[S.MENU] = s

	var title := _label("HOOP FLIGHT", 82, ACCENT)
	title.set_anchors_preset(Control.PRESET_CENTER_TOP)
	title.position = Vector2(-330, 52)
	title.size = Vector2(660, 90)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	s.add_child(title)

	var sub := _label("баскетбольный мяч сквозь кольца", 24, Color(0.85, 0.88, 0.95))
	sub.set_anchors_preset(Control.PRESET_CENTER_TOP)
	sub.position = Vector2(-330, 158)
	sub.size = Vector2(660, 34)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	s.add_child(sub)

	var icon := BallIcon.new()
	icon.set_anchors_preset(Control.PRESET_CENTER_TOP)
	icon.position = Vector2(-56, 196)
	icon.size = Vector2(112, 112)
	s.add_child(icon)
	icon.set_meta("live", true)

	var v := _vbox(s, 12, 230.0)
	var b1 := _button("ИГРАТЬ", 420, 70)
	b1.pressed.connect(func(): _go(S.MODES))
	v.add_child(b1)
	var b2 := _button("МАГАЗИН МЯЧЕЙ", 420, 60, Color(0.45, 0.62, 1.0))
	b2.pressed.connect(func():
		_refresh_shop()
		_go(S.SHOP))
	v.add_child(b2)
	var b3 := _button("СТАТИСТИКА", 420, 60, Color(0.55, 0.75, 0.65))
	b3.pressed.connect(func():
		_refresh_stats()
		_go(S.STATS))
	v.add_child(b3)

	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(h)
	var snd := _button("", 204, 52, Color(0.35, 0.38, 0.48))
	var mus := _button("", 204, 52, Color(0.35, 0.38, 0.48))
	var upd := func():
		snd.text = "Звук: ВКЛ" if SaveData.data["sound"] else "Звук: выкл"
		mus.text = "Музыка: ВКЛ" if SaveData.data["music"] else "Музыка: выкл"
	snd.pressed.connect(func():
		SaveData.data["sound"] = not SaveData.data["sound"]
		SaveData.save_game()
		upd.call())
	mus.pressed.connect(func():
		SaveData.data["music"] = not SaveData.data["music"]
		SaveData.save_game()
		Sfx.refresh_music()
		upd.call())
	h.add_child(snd)
	h.add_child(mus)
	upd.call()

	_coin_label(s)
	# обновляем предпросмотр выбранного мяча при входе в меню
	s.visibility_changed.connect(func():
		if s.visible:
			icon.skin = SaveData.current_skin()
			_refresh_coins())


func _build_modes() -> void:
	var s := _screen()
	_dim(s)
	screens[S.MODES] = s

	var title := _label("ВЫБЕРИ РЕЖИМ", 46, ACCENT)
	title.set_anchors_preset(Control.PRESET_CENTER_TOP)
	title.position = Vector2(-330, 28)
	title.size = Vector2(660, 56)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	s.add_child(title)

	var v := _vbox(s, 10, 70.0)
	for m in Modes.LIST:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 14)
		row.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		var b := _button(String(m["name"]), 330, 56, Color(m["tint"]).lerp(ACCENT, 0.35))
		var mid := String(m["id"])
		b.pressed.connect(func(): _start_run(mid))
		row.add_child(b)
		var info := _label("", 20, Color(0.85, 0.88, 0.95))
		info.custom_minimum_size = Vector2(560, 56)
		info.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(info)
		v.add_child(row)
		s.visibility_changed.connect(func():
			if s.visible:
				info.text = "%s\nЛучший счёт: %d   колец: %d" % [
					String(m["desc"]), SaveData.best_score(mid), SaveData.best_hoops(mid)])

	var back := _button("НАЗАД", 240, 52, Color(0.4, 0.42, 0.5))
	back.pressed.connect(func(): _go(S.MENU))
	v.add_child(back)


func _build_shop() -> void:
	var s := _screen()
	_dim(s)
	screens[S.SHOP] = s

	var title := _label("МАГАЗИН МЯЧЕЙ", 44, ACCENT)
	title.set_anchors_preset(Control.PRESET_CENTER_TOP)
	title.position = Vector2(-330, 18)
	title.size = Vector2(660, 52)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	s.add_child(title)
	_coin_label(s)

	var scroll := ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	scroll.offset_left = 70
	scroll.offset_right = -70
	scroll.offset_top = 84
	scroll.offset_bottom = -88
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	s.add_child(scroll)

	shop_box = VBoxContainer.new()
	shop_box.add_theme_constant_override("separation", 10)
	shop_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(shop_box)

	var back := _button("НАЗАД", 240, 54, Color(0.4, 0.42, 0.5))
	back.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	back.position = Vector2(70, -74)
	back.pressed.connect(func(): _go(S.MENU))
	s.add_child(back)


func _refresh_shop() -> void:
	for c in shop_box.get_children():
		c.queue_free()
	_refresh_coins()
	for sk in Skins.LIST:
		var id := String(sk["id"])
		var row := PanelContainer.new()
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.13, 0.15, 0.22, 0.95)
		sb.set_corner_radius_all(12)
		sb.set_content_margin_all(10)
		if SaveData.data["skin"] == id:
			sb.border_color = ACCENT
			sb.set_border_width_all(3)
		row.add_theme_stylebox_override("panel", sb)

		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 16)
		row.add_child(h)

		var icon := BallIcon.new()
		icon.skin = sk
		icon.custom_minimum_size = Vector2(84, 84)
		h.add_child(icon)

		var texts := VBoxContainer.new()
		texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var nm := _label(String(sk["name"]), 26, Color(1, 1, 1))
		texts.add_child(nm)
		var ds := _label(String(sk["desc"]), 19, Color(0.78, 0.82, 0.92))
		ds.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		ds.custom_minimum_size = Vector2(560, 0)
		texts.add_child(ds)
		h.add_child(texts)

		var price := int(sk["price"])
		var owned: bool = SaveData.owns(id)
		var action: Button
		if owned:
			if SaveData.data["skin"] == id:
				action = _button("ВЫБРАН", 210, 54, Color(0.35, 0.7, 0.45))
				action.disabled = true
			else:
				action = _button("ВЫБРАТЬ", 210, 54, Color(0.45, 0.62, 1.0))
				action.pressed.connect(func():
					SaveData.select_skin(id)
					_refresh_shop())
		elif price > 0:
			action = _button("КУПИТЬ  %d" % price, 210, 54,
				ACCENT if SaveData.coins() >= price else Color(0.42, 0.42, 0.48))
			action.pressed.connect(func():
				if SaveData.spend(price):
					SaveData.unlock(id)
					SaveData.select_skin(id)
					Sfx.play("buy", -6.0)
					_refresh_shop()
				else:
					Sfx.play("hurt", -14.0))
		elif int(sk["free_rank"]) >= 0:
			var need: int = Skins.FREE_THRESHOLDS[int(sk["free_rank"])]
			action = _button("%d колец" % need, 210, 54, Color(0.42, 0.42, 0.48))
			action.disabled = true
		else:
			action = _button("Ультра x25", 210, 54, Color(0.42, 0.42, 0.48))
			action.disabled = true
		h.add_child(action)
		shop_box.add_child(row)


func _build_stats() -> void:
	var s := _screen()
	_dim(s)
	screens[S.STATS] = s

	var title := _label("СТАТИСТИКА", 44, ACCENT)
	title.set_anchors_preset(Control.PRESET_CENTER_TOP)
	title.position = Vector2(-330, 26)
	title.size = Vector2(660, 52)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	s.add_child(title)

	stats_body = _label("", 24, Color(0.9, 0.93, 1.0))
	stats_body.set_anchors_preset(Control.PRESET_FULL_RECT)
	stats_body.offset_left = 210
	stats_body.offset_right = -210
	stats_body.offset_top = 100
	stats_body.offset_bottom = -150
	s.add_child(stats_body)

	var back := _button("НАЗАД", 240, 54, Color(0.4, 0.42, 0.5))
	back.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	back.offset_left = 520
	back.offset_right = -520
	back.offset_top = -86
	back.offset_bottom = -32
	back.pressed.connect(func(): _go(S.MENU))
	s.add_child(back)


func _refresh_stats() -> void:
	var lines: Array[String] = []
	lines.append("Очков накоплено: %d" % SaveData.coins())
	lines.append("Всего колец пройдено: %d" % int(SaveData.data["total_hoops"]))
	lines.append("Забегов: %d" % int(SaveData.data["runs"]))
	lines.append("Лучшая серия: %d" % int(SaveData.data["best_combo"]))
	lines.append("Мячей открыто: %d из %d" % [SaveData.data["owned"].size(), Skins.count()])
	var nxt := SaveData.next_free_threshold()
	if nxt > 0:
		lines.append("До следующего бесплатного мяча: %d колец" % max(0, nxt - int(SaveData.data["total_hoops"])))
	else:
		lines.append("Все достижения по кольцам получены!")
	lines.append("")
	lines.append("Рекорды по режимам:")
	for m in Modes.LIST:
		lines.append("   %-16s счёт %6d    колец %5d" % [
			String(m["name"]), SaveData.best_score(String(m["id"])), SaveData.best_hoops(String(m["id"]))])
	stats_body.text = "\n".join(lines)


func _build_hud() -> void:
	var s := _screen()
	screens[S.PLAY] = s

	hud_score = _label("0", 64, Color(1, 1, 1))
	hud_score.set_anchors_preset(Control.PRESET_CENTER_TOP)
	hud_score.position = Vector2(-200, 16)
	hud_score.size = Vector2(400, 74)
	hud_score.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	s.add_child(hud_score)

	hud_lives = _label("", 40, Color(1, 0.35, 0.4))
	hud_lives.set_anchors_preset(Control.PRESET_TOP_LEFT)
	hud_lives.position = Vector2(26, 18)
	s.add_child(hud_lives)

	hud_combo = _label("", 28, Color(1, 0.85, 0.35))
	hud_combo.set_anchors_preset(Control.PRESET_TOP_LEFT)
	hud_combo.position = Vector2(26, 70)
	s.add_child(hud_combo)

	hud_buffs = _label("", 24, Color(0.7, 1.0, 1.0))
	hud_buffs.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	hud_buffs.position = Vector2(-400, -56)
	hud_buffs.size = Vector2(800, 34)
	hud_buffs.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	s.add_child(hud_buffs)

	var pause_btn := _button("II", 74, 56, Color(0.25, 0.28, 0.36))
	pause_btn.add_theme_color_override("font_color", Color(1, 1, 1))
	pause_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	pause_btn.position = Vector2(-96, 18)
	pause_btn.pressed.connect(_pause)
	s.add_child(pause_btn)


func _build_pause() -> void:
	var s := _screen()
	_dim(s, 0.75)
	screens[S.PAUSE] = s
	var v := _vbox(s, 14)
	var t := _label("ПАУЗА", 56, ACCENT)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.custom_minimum_size = Vector2(420, 70)
	v.add_child(t)
	var b1 := _button("ПРОДОЛЖИТЬ", 420, 62)
	b1.pressed.connect(_resume)
	v.add_child(b1)
	var b2 := _button("НАЧАТЬ ЗАНОВО", 420, 56, Color(0.45, 0.62, 1.0))
	b2.pressed.connect(func(): _start_run(current_mode))
	v.add_child(b2)
	var b3 := _button("В МЕНЮ", 420, 56, Color(0.4, 0.42, 0.5))
	b3.pressed.connect(func():
		play.stop()
		get_tree().paused = false
		Sfx.play_music("calm")
		_go(S.MENU))
	v.add_child(b3)


func _build_over() -> void:
	var s := _screen()
	_dim(s, 0.82)
	screens[S.OVER] = s

	over_title = _label("ИГРА ОКОНЧЕНА", 58, Color(1, 0.45, 0.35))
	over_title.set_anchors_preset(Control.PRESET_CENTER_TOP)
	over_title.position = Vector2(-400, 46)
	over_title.size = Vector2(800, 70)
	over_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	s.add_child(over_title)

	over_body = _label("", 28, Color(0.92, 0.95, 1.0))
	over_body.set_anchors_preset(Control.PRESET_CENTER_TOP)
	over_body.position = Vector2(-400, 130)
	over_body.size = Vector2(800, 340)
	over_body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	s.add_child(over_body)

	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 18)
	h.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.offset_top = -108
	h.offset_bottom = -40
	s.add_child(h)
	var again := _button("ИГРАТЬ СНОВА", 320, 64)
	again.pressed.connect(func(): _start_run(current_mode))
	h.add_child(again)
	var menu := _button("В МЕНЮ", 320, 64, Color(0.4, 0.42, 0.5))
	menu.pressed.connect(func():
		Sfx.play_music("calm")
		_go(S.MENU))
	h.add_child(menu)


func _build_reward_label() -> void:
	reward_label = _label("", 40, Color(1, 0.9, 0.4))
	reward_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	reward_label.position = Vector2(-450, 120)
	reward_label.size = Vector2(900, 60)
	reward_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	reward_label.visible = false
	ui.add_child(reward_label)


# ================= управление состоянием =================

func _go(new_state: int) -> void:
	state = new_state
	play.menu_mode = (new_state != S.PLAY and new_state != S.PAUSE)
	for key in screens.keys():
		screens[key].visible = (key == new_state)
	if new_state == S.MENU or new_state == S.SHOP:
		_refresh_coins()


func _start_run(mode_id: String) -> void:
	current_mode = mode_id
	get_tree().paused = false
	play.start(mode_id)
	_go(S.PLAY)


func _pause() -> void:
	if state != S.PLAY:
		return
	get_tree().paused = true
	_go(S.PAUSE)


func _resume() -> void:
	get_tree().paused = false
	_go(S.PLAY)


func _on_game_over(stats: Dictionary) -> void:
	var mode_id := String(stats["mode"])
	var prev_best := SaveData.best_score(mode_id)
	var rewards := SaveData.finish_run(mode_id, int(stats["score"]), int(stats["hoops"]), int(stats["best_combo"]))
	var lines: Array[String] = []
	lines.append("Режим: %s" % String(Modes.by_id(mode_id)["name"]))
	lines.append("")
	lines.append("Счёт: %d" % int(stats["score"]))
	lines.append("Колец пройдено: %d" % int(stats["hoops"]))
	lines.append("Лучшая серия: %d" % int(stats["best_combo"]))
	lines.append("Огненных идеально: %d     промахов: %d" % [int(stats["perfect"]), int(stats["missed"])])
	lines.append("Причина: %s" % String(stats["reason"]))
	lines.append("")
	if int(stats["score"]) > prev_best:
		lines.append("★ НОВЫЙ РЕКОРД! (было %d)" % prev_best)
	else:
		lines.append("Рекорд режима: %d" % SaveData.best_score(mode_id))
	lines.append("Очков в копилке: %d" % SaveData.coins())
	for r in rewards:
		lines.append("🏆 " + String(r))
	if rewards.size() > 0:
		Sfx.play("achieve", -4.0)
	over_body.text = "\n".join(lines)
	over_title.text = "ИГРА ОКОНЧЕНА"
	_go(S.OVER)


func _on_reward(text: String) -> void:
	reward_label.text = text
	reward_t = 4.0


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
		SaveData.save_game()
