# Play.gd — сам геймплей: физика мяча, кольца, огонь, серии, жизни, частицы.
# Вся графика рисуется кодом в _draw(), внешних картинок нет.
class_name Play
extends Node2D

signal game_over(stats: Dictionary)
signal reward(text: String)

const W := 1280.0
const H := 720.0
const GROUND_Y := 648.0
const CEIL_Y := 8.0
const BALL_X := 330.0
const BALL_R := 24.0

# базовые пороги серий (скин может уменьшить их)
const COMBO_GHOST := 10
const COMBO_SLOWMO := 20
const COMBO_SHIELD := 30
const COMBO_DOUBLE := 50

var mode: Dictionary = {}
var skin: Dictionary = {}
var mods: Dictionary = {}

# --- состояние забега ---
var running := false
var started := false          # игрок сделал первое касание
var score := 0
var hoops_passed := 0
var combo := 0
var best_combo := 0
var lives := 3
var max_lives := 3
var perfect_count := 0        # сколько огненных колец пройдено идеально
var missed := 0

# --- мяч ---
var ball_y := 300.0
var ball_v := 0.0
var ball_spin := 0.0
var invuln := 0.0
var ground_save_used := false
var slow_fall_t := 0.0

# --- кольца ---
var hoops: Array = []
var since_rare := 0
var since_epic := 0
var since_legendary := 0
var speed := 265.0
var spacing := 430.0
var gate := 64.0

# --- баффы серий ---
var ghost_t := 0.0
var slowmo_t := 0.0
var shield := false
var double_t := 0.0
var granted := {}             # какие пороги серии уже сработали в этой серии

# --- визуал ---
var particles: Array = []
var floats: Array = []        # всплывающий текст очков
var bg_off := [0.0, 0.0, 0.0]
var shake := 0.0
var flash := 0.0
var flash_color := Color(1, 1, 1, 0)
var time := 0.0
var menu_mode := true          # в меню рисуем только фон
var rng := RandomNumberGenerator.new()


func _ready() -> void:
	rng.randomize()
	set_process_unhandled_input(true)


func start(mode_id: String) -> void:
	mode = Modes.by_id(mode_id)
	skin = SaveData.current_skin()
	mods = Skins.mods(String(skin["ability"]))

	score = 0
	hoops_passed = 0
	combo = 0
	best_combo = 0
	perfect_count = 0
	missed = 0
	max_lives = int(mode["lives"]) + int(mods["extra_life"])
	lives = max_lives
	ball_y = 320.0
	ball_v = 0.0
	ball_spin = 0.0
	invuln = 0.0
	ground_save_used = false
	slow_fall_t = 0.0
	hoops.clear()
	particles.clear()
	floats.clear()
	since_rare = 0
	since_epic = 0
	since_legendary = 0
	speed = float(mode["speed"])
	spacing = float(mode["spacing"])
	gate = float(mode["gate"])
	ghost_t = 0.0
	slowmo_t = 0.0
	double_t = 0.0
	shield = false
	granted.clear()
	running = true
	started = false
	menu_mode = false
	_spawn_initial()
	Sfx.play_music(String(mode["music"]))


func stop() -> void:
	running = false


func _unhandled_input(event: InputEvent) -> void:
	if not running:
		return
	var tapped := false
	if event is InputEventScreenTouch and event.pressed:
		tapped = true
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		tapped = true
	elif event.is_action_pressed("flap"):
		tapped = true
	if tapped:
		_flap()


func _flap() -> void:
	started = true
	var power := float(mode["jump"]) * float(mods["jump_mult"])
	ball_v = power
	ball_spin -= 3.5
	Sfx.play("flap", -14.0, rng.randf_range(0.94, 1.08))
	for i in 6:
		_add_particle(Vector2(BALL_X - 10, ball_y + BALL_R * 0.6),
			Vector2(rng.randf_range(-160, -40), rng.randf_range(-40, 60)),
			Color(1, 1, 1, 0.5), rng.randf_range(2, 4), 0.35)


func _process(delta: float) -> void:
	time += delta
	delta = min(delta, 1.0 / 30.0)     # защита от рывков при просадке FPS

	# таймеры баффов
	ghost_t = max(0.0, ghost_t - delta)
	slowmo_t = max(0.0, slowmo_t - delta)
	double_t = max(0.0, double_t - delta)
	invuln = max(0.0, invuln - delta)
	slow_fall_t = max(0.0, slow_fall_t - delta)
	shake = max(0.0, shake - delta * 3.0)
	flash = max(0.0, flash - delta * 2.5)

	var time_scale := 0.62 if slowmo_t > 0.0 else 1.0
	var dt := delta * time_scale

	if running:
		_update_physics(dt)
		_update_hoops(dt)
	_update_particles(delta)
	_update_floats(delta)

	var bg_speed: float = speed if running else 60.0
	bg_off[0] += bg_speed * 0.12 * dt
	bg_off[1] += bg_speed * 0.32 * dt
	bg_off[2] += bg_speed * 0.75 * dt
	queue_redraw()


func _update_physics(dt: float) -> void:
	if not started:
		# до первого касания мяч мягко парит
		ball_y = 320.0 + sin(time * 2.2) * 18.0
		ball_spin += dt * 1.2
		return

	var g := float(mode["gravity"]) * float(mods["gravity_mult"])
	if slow_fall_t > 0.0 and ball_v > 0.0:
		g *= 0.7
	ball_v += g * dt
	ball_v = min(ball_v, 1250.0)
	ball_y += ball_v * dt
	ball_spin += (0.6 + abs(ball_v) / 900.0) * dt * 6.0

	if ball_y < CEIL_Y + BALL_R:
		ball_y = CEIL_Y + BALL_R
		ball_v = max(ball_v, 0.0)

	if ball_y > GROUND_Y - BALL_R:
		_hit_ground()


func _hit_ground() -> void:
	if invuln > 0.0:
		ball_y = GROUND_Y - BALL_R
		ball_v = -abs(ball_v) * 0.4
		return
	if bool(mods["ground_save"]) and not ground_save_used:
		ground_save_used = true
		ball_y = GROUND_Y - BALL_R - 4.0
		ball_v = float(mode["jump"]) * 1.1
		_pop_text("СПАСЕНИЕ!", Color(1, 0.95, 0.6))
		Sfx.play("buff", -6.0)
		_burst(Vector2(BALL_X, ball_y), Color(1, 0.95, 0.6), 26)
		return
	if shield:
		shield = false
		ball_y = GROUND_Y - BALL_R - 4.0
		ball_v = float(mode["jump"])
		_pop_text("ЩИТ!", Color(0.6, 0.9, 1))
		Sfx.play("buff", -6.0)
		return
	_lose_life("Земля")


func _lose_life(reason: String) -> void:
	lives -= 1
	combo = 0
	granted.clear()
	ghost_t = 0.0
	slowmo_t = 0.0
	double_t = 0.0
	shake = 1.0
	flash = 1.0
	flash_color = Color(1, 0.25, 0.15, 0.5)
	_burst(Vector2(BALL_X, ball_y), Color(1, 0.4, 0.2), 34)
	Sfx.play("hurt", -4.0)

	if lives <= 0:
		running = false
		Sfx.play("gameover", -3.0)
		Sfx.stop_music()
		game_over.emit({
			"score": score, "hoops": hoops_passed, "best_combo": best_combo,
			"perfect": perfect_count, "missed": missed, "reason": reason,
			"mode": String(mode["id"]),
		})
		return

	# продолжаем: возвращаем мяч в центр и расчищаем ближние кольца
	ball_y = 300.0
	ball_v = -120.0
	invuln = 1.3
	for h in hoops:
		if h["x"] > BALL_X - 60 and h["x"] < BALL_X + 260:
			h["passed"] = true
			h["result"] = "skip"


# ---------------- кольца ----------------

func _spawn_initial() -> void:
	var x := W + 220.0
	for i in 3:
		_spawn_hoop(x)
		x += spacing


func _spawn_hoop(x: float) -> void:
	# тип кольца: счётчики гарантируют примерную периодичность
	var type := "common"
	since_rare += 1
	since_epic += 1
	since_legendary += 1
	if since_legendary >= Modes.LEG_EVERY:
		type = "legendary"
		since_legendary = 0
	elif since_epic >= Modes.EPIC_EVERY:
		type = "epic"
		since_epic = 0
	elif since_rare >= Modes.RARE_EVERY:
		type = "rare"
		since_rare = 0
	# независимый бросок на божественное кольцо
	if rng.randf() < Modes.DIVINE_CHANCE:
		type = "divine"

	var fire := rng.randf() < float(mode["fire_chance"])
	var margin := gate + 90.0
	var y := rng.randf_range(CEIL_Y + margin, GROUND_Y - margin)
	# не даём соседним кольцам сильно прыгать по высоте
	if hoops.size() > 0:
		var last_y: float = hoops[hoops.size() - 1]["y"]
		y = clamp(y, last_y - 250.0, last_y + 250.0)
		y = clamp(y, CEIL_Y + margin, GROUND_Y - margin)

	hoops.append({
		"x": x, "y": y, "type": type, "fire": fire, "gate": gate,
		"passed": false, "result": "", "anim": 0.0, "phase": rng.randf() * TAU,
	})


func _update_hoops(dt: float) -> void:
	# сложность растёт вместе со счётом пройденных колец
	speed = min(float(mode["speed"]) + float(mode["speed_gain"]) * hoops_passed, float(mode["speed_max"]))
	spacing = max(float(mode["spacing"]) - hoops_passed * 2.2, float(mode["spacing_min"]))
	gate = max(float(mode["gate"]) - hoops_passed * 0.55, float(mode["gate_min"]))

	var last_x := -1000.0
	for h in hoops:
		var prev: float = h["x"]
		h["x"] = prev - speed * dt
		h["anim"] = max(0.0, float(h["anim"]) - dt * 2.0)
		last_x = max(last_x, float(h["x"]))
		if not h["passed"] and prev > BALL_X and float(h["x"]) <= BALL_X:
			_evaluate(h)

	while last_x < W + spacing:
		_spawn_hoop(last_x + spacing)
		last_x += spacing

	# убираем уехавшие
	var keep: Array = []
	for h in hoops:
		if float(h["x"]) > -160.0:
			keep.append(h)
	hoops = keep


func _evaluate(h: Dictionary) -> void:
	h["passed"] = true
	h["anim"] = 1.0
	var dy: float = abs(ball_y - float(h["y"]))
	var g: float = float(h["gate"]) * (1.0 + float(mods["gate_bonus"]))
	if ghost_t > 0.0:
		g *= 1.15
	var immune: bool = bool(mods["fire_immune"]) or ghost_t > 0.0
	var is_fire: bool = bool(h["fire"])

	if is_fire and not immune:
		var center: float = g * 0.5
		if dy <= center:
			_success(h, true)
		elif dy <= g * 1.4:
			# задели границу огненного кольца — очки не начисляем
			h["result"] = "burn"
			combo = 0
			granted.clear()
			missed += 1
			Sfx.play("burn", -4.0)
			_burst(Vector2(BALL_X, ball_y), Color(1, 0.5, 0.1), 30)
			_pop_text("ОБЖЁГСЯ!", Color(1, 0.5, 0.2))
			if shield:
				shield = false
				_pop_text("ЩИТ ПОГЛОТИЛ", Color(0.6, 0.9, 1))
			else:
				_lose_life("Огненное кольцо")
		else:
			_miss(h)
	else:
		if dy <= g:
			_success(h, is_fire)
		else:
			_miss(h)


func _miss(h: Dictionary) -> void:
	h["result"] = "miss"
	combo = 0
	granted.clear()
	missed += 1
	_pop_text("мимо", Color(0.8, 0.8, 0.85))


func _success(h: Dictionary, fire_bonus: bool) -> void:
	h["result"] = "pass"
	var type := String(h["type"])
	var info: Dictionary = Modes.RING_TYPES[type]
	var pts := int(info["points"])
	if fire_bonus and bool(h["fire"]):
		pts *= 2
		perfect_count += 1
		double_t = max(double_t, 2.5)     # короткий множитель после огня
	if double_t > 0.0:
		pts *= 2
	if type == "common" and rng.randf() < float(mods["magnet_chance"]):
		pts += int(mods["magnet_points"])
	pts = int(round(pts * float(mods["points_mult"])))

	score += pts
	hoops_passed += 1
	combo += 1
	best_combo = max(best_combo, combo)
	if bool(mods["slow_fall"]):
		slow_fall_t = 1.0

	Sfx.play(type, -6.0)
	if bool(h["fire"]):
		Sfx.play("fire", -12.0)

	var col: Color = info["color"]
	_pop_text("+%d" % pts, col)
	_burst(Vector2(BALL_X, ball_y), col, 12 if type == "common" else 26)
	if type == "divine":
		_confetti()
		flash = 1.0
		flash_color = Color(1, 1, 1, 0.55)

	_check_combo()
	_check_ultra()


func _check_combo() -> void:
	var m := float(mods["combo_mult"])
	var thresholds := {
		"ghost": int(round(COMBO_GHOST * m)),
		"slowmo": int(round(COMBO_SLOWMO * m)),
		"shield": int(round(COMBO_SHIELD * m)),
		"double": int(round(COMBO_DOUBLE * m)),
	}
	for key in thresholds.keys():
		var need: int = thresholds[key]
		if combo >= need and not granted.has(key):
			granted[key] = true
			match key:
				"ghost":
					ghost_t = 3.0
					_pop_text("ПРИЗРАК 3с", Color(0.7, 1, 1))
				"slowmo":
					slowmo_t = 4.0
					_pop_text("ЗАМЕДЛЕНИЕ 4с", Color(0.6, 0.8, 1))
				"shield":
					shield = true
					_pop_text("ЩИТ", Color(0.5, 1, 0.8))
				"double":
					double_t = 6.0
					_pop_text("x2 ОЧКИ 6с", Color(1, 0.9, 0.3))
			Sfx.play("buff", -6.0)


func _check_ultra() -> void:
	if String(mode["id"]) == "ultra" and combo >= 25 and not bool(SaveData.data["ultra_reward"]):
		if SaveData.grant_ultra_reward():
			Sfx.play("achieve", -3.0)
			_confetti()
			reward.emit("ЛЕГЕНДАРНЫЙ МЯЧ ОТКРЫТ!")


# ---------------- частицы и текст ----------------

func _add_particle(pos: Vector2, vel: Vector2, col: Color, size: float, life: float) -> void:
	particles.append({"p": pos, "v": vel, "c": col, "s": size, "l": life, "t": life})


func _burst(pos: Vector2, col: Color, n: int) -> void:
	for i in n:
		var a := rng.randf() * TAU
		var sp := rng.randf_range(60, 340)
		_add_particle(pos, Vector2(cos(a), sin(a)) * sp, col, rng.randf_range(2.5, 6.0), rng.randf_range(0.3, 0.7))


func _confetti() -> void:
	for i in 60:
		var a := rng.randf() * TAU
		var sp := rng.randf_range(120, 520)
		var col := Color.from_hsv(rng.randf(), 0.8, 1.0)
		_add_particle(Vector2(BALL_X, ball_y), Vector2(cos(a), sin(a)) * sp, col, rng.randf_range(3, 7), rng.randf_range(0.6, 1.3))


func _pop_text(txt: String, col: Color) -> void:
	floats.append({"t": txt, "c": col, "p": Vector2(BALL_X + 40, ball_y - 30), "l": 1.0})


func _update_particles(delta: float) -> void:
	var keep: Array = []
	for p in particles:
		p["l"] = float(p["l"]) - delta
		if p["l"] <= 0.0:
			continue
		var v: Vector2 = p["v"]
		v.y += 520.0 * delta
		v.x -= speed * 0.35 * delta
		p["v"] = v
		p["p"] = Vector2(p["p"]) + v * delta
		keep.append(p)
	particles = keep


func _update_floats(delta: float) -> void:
	var keep: Array = []
	for f in floats:
		f["l"] = float(f["l"]) - delta
		if f["l"] <= 0.0:
			continue
		f["p"] = Vector2(f["p"]) + Vector2(-speed * 0.25 * delta, -60.0 * delta)
		keep.append(f)
	floats = keep


# ---------------- отрисовка ----------------

func _draw() -> void:
	var off := Vector2.ZERO
	if shake > 0.0:
		off = Vector2(rng.randf_range(-1, 1), rng.randf_range(-1, 1)) * shake * 9.0
	draw_set_transform(off, 0.0, Vector2.ONE)

	_draw_background()
	if menu_mode:
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		return
	for h in hoops:
		_draw_hoop(h, true)
	_draw_ball()
	for h in hoops:
		_draw_hoop(h, false)
	_draw_particles()
	_draw_floats()

	if flash > 0.0:
		var c := flash_color
		c.a *= flash
		draw_rect(Rect2(-50, -50, W + 100, H + 100), c)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_background() -> void:
	var tint: Color = mode.get("tint", Color(0.42, 0.68, 0.92))
	# небо — вертикальный градиент полосами
	var steps := 22
	for i in steps:
		var f := float(i) / steps
		var c := tint.lerp(Color(0.98, 0.92, 0.80), f * 0.75)
		draw_rect(Rect2(0, H * f, W, H / steps + 1), c)

	# дальние холмы
	_draw_hills(bg_off[0], 470.0, tint.darkened(0.35).lerp(Color(0.2, 0.3, 0.45), 0.35), 90.0, 620.0)
	# средние холмы
	_draw_hills(bg_off[1], 540.0, tint.darkened(0.5).lerp(Color(0.15, 0.35, 0.3), 0.45), 60.0, 380.0)
	# силуэты домов/деревьев
	_draw_props(bg_off[2])

	# земля
	draw_rect(Rect2(0, GROUND_Y, W, H - GROUND_Y), Color(0.22, 0.17, 0.13))
	draw_rect(Rect2(0, GROUND_Y, W, 10), Color(0.36, 0.28, 0.18))
	var stripe := fposmod(bg_off[2], 80.0)
	for i in range(-1, 18):
		var x := i * 80.0 - stripe
		draw_rect(Rect2(x, GROUND_Y + 14, 44, 6), Color(0.30, 0.23, 0.16))


func _draw_hills(offset: float, base_y: float, col: Color, amp: float, period: float) -> void:
	var pts := PackedVector2Array()
	var x := -40.0
	while x <= W + 40.0:
		var y := base_y - sin((x + offset) / period * TAU) * amp - cos((x + offset) / (period * 0.37) * TAU) * amp * 0.28
		pts.append(Vector2(x, y))
		x += 20.0
	pts.append(Vector2(W + 40, H))
	pts.append(Vector2(-40, H))
	draw_colored_polygon(pts, col)


func _draw_props(offset: float) -> void:
	var period := 260.0
	var start := -fposmod(offset, period)
	var i := 0
	var x := start
	while x < W + period:
		var kind := int(abs(floor((x + offset) / period))) % 3
		var h := 90.0 + kind * 40.0
		var col := Color(0.14, 0.20, 0.24, 0.85)
		if kind == 1:
			# дерево
			draw_rect(Rect2(x + 20, GROUND_Y - 60, 12, 60), col)
			draw_circle(Vector2(x + 26, GROUND_Y - 78), 34, col)
			draw_circle(Vector2(x + 50, GROUND_Y - 62), 24, col)
		else:
			# дом
			draw_rect(Rect2(x, GROUND_Y - h, 74, h), col)
			var roof := PackedVector2Array([
				Vector2(x - 8, GROUND_Y - h), Vector2(x + 37, GROUND_Y - h - 34), Vector2(x + 82, GROUND_Y - h)])
			draw_colored_polygon(roof, col.darkened(0.2))
			for wy in range(1, int(h / 34)):
				draw_rect(Rect2(x + 14, GROUND_Y - h + wy * 30, 14, 14), Color(1, 0.85, 0.5, 0.35))
				draw_rect(Rect2(x + 44, GROUND_Y - h + wy * 30, 14, 14), Color(1, 0.85, 0.5, 0.25))
		x += period
		i += 1


func _ellipse_points(center: Vector2, rx: float, ry: float, from_a: float, to_a: float, n: int = 26) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in range(n + 1):
		var a: float = lerp(from_a, to_a, float(i) / n)
		pts.append(center + Vector2(cos(a) * rx, sin(a) * ry))
	return pts


func _draw_hoop(h: Dictionary, back: bool) -> void:
	var x := float(h["x"])
	if x < -180 or x > W + 180:
		return
	var y := float(h["y"])
	var type := String(h["type"])
	var info: Dictionary = Modes.RING_TYPES[type]
	var col: Color = info["color"]
	var glow: Color = info["glow"]
	# Кольцо лежит "плашмя": по горизонтали шире, по вертикали — проход для мяча.
	var ry := float(h["gate"])            # половина прохода (по ней же считается попадание)
	var rx := ry * 1.55 + 26.0            # видимая ширина обода
	var center := Vector2(x, y)
	var passed := bool(h["passed"])
	var res := String(h["result"])
	var anim := float(h["anim"])

	if passed and res == "pass":
		col = col.lerp(Color(0.55, 1.0, 0.65), 0.40)
	elif passed and (res == "miss" or res == "burn"):
		col = col.darkened(0.45)

	var width := 8.0 + anim * 5.0

	if back:
		if glow.a > 0.05:
			var gp := _ellipse_points(center, rx + 7, ry + 7, 0, TAU, 44)
			draw_polyline(gp, Color(glow.r, glow.g, glow.b, glow.a * (0.30 + anim * 0.5)), 13.0, true)
		# дальняя (верхняя) половина обода — рисуется ЗА мячом
		draw_polyline(_ellipse_points(center, rx, ry, PI, TAU), col.darkened(0.30), width, true)
		# сетка под кольцом
		var net_col := Color(0.96, 0.96, 1.0, 0.30)
		var depth := ry * 1.15 + 26.0
		for i in 11:
			var a: float = lerp(0.0, TAU, float(i) / 11.0)
			var p0 := center + Vector2(cos(a) * rx, sin(a) * ry)
			var p1 := center + Vector2(cos(a) * rx * 0.42, ry * 0.42 + depth)
			draw_line(p0, p1, net_col, 2.0)
		draw_polyline(_ellipse_points(center + Vector2(0, depth), rx * 0.42, ry * 0.42, 0, TAU, 22), net_col, 2.0, true)
		# щит-подставка сзади, чтобы кольцо читалось как баскетбольное
		draw_line(center + Vector2(0, -ry), center + Vector2(0, -ry - 26), col.darkened(0.5), 4.0)
		draw_rect(Rect2(center.x - 36, center.y - ry - 76, 72, 50), Color(0.96, 0.97, 1.0, 0.30))
		draw_rect(Rect2(center.x - 36, center.y - ry - 76, 72, 50), col.darkened(0.25), false, 3.0)
		draw_rect(Rect2(center.x - 15, center.y - ry - 54, 30, 22), col.darkened(0.25), false, 2.0)
	else:
		# ближняя (нижняя) половина обода — рисуется ПЕРЕД мячом
		draw_polyline(_ellipse_points(center, rx, ry, 0, PI), col, width, true)
		if bool(h["fire"]):
			_draw_fire(center, rx, ry, float(h["phase"]))
		if type == "divine":
			for i in 6:
				var a := time * 1.6 + i * TAU / 6.0
				draw_circle(center + Vector2(cos(a) * (rx + 14), sin(a) * (ry + 14)), 3.5, Color(1, 1, 1, 0.85))


func _draw_fire(center: Vector2, rx: float, ry: float, phase: float) -> void:
	var n := 34
	for i in n:
		var a := TAU * float(i) / n
		var wob := sin(time * 9.0 + a * 3.0 + phase) * 0.5 + 0.5
		var r := 9.0 + wob * 11.0
		var p := center + Vector2(cos(a) * rx, sin(a) * ry)
		draw_circle(p, r, Color(1.0, 0.35, 0.05, 0.20))
		draw_circle(p, r * 0.6, Color(1.0, 0.65, 0.15, 0.35))
		draw_circle(p, r * 0.3, Color(1.0, 0.95, 0.6, 0.5))


func _draw_ball() -> void:
	var pos := Vector2(BALL_X, ball_y)
	var main: Color = skin.get("main", Color(0.85, 0.33, 0.13))
	var line: Color = skin.get("line", Color(0.15, 0.09, 0.06))
	var glow: Color = skin.get("glow", Color(0, 0, 0, 0))

	if invuln > 0.0 and int(invuln * 12.0) % 2 == 0:
		main = main.lerp(Color(1, 1, 1), 0.6)
	if ghost_t > 0.0:
		main.a = 0.55
		line.a = 0.55

	# тень на земле
	var d: float = clamp((GROUND_Y - ball_y) / 400.0, 0.15, 1.0)
	draw_circle(Vector2(BALL_X, GROUND_Y + 4), BALL_R * (1.4 - d * 0.6), Color(0, 0, 0, 0.18 * (1.2 - d)))

	if glow.a > 0.02:
		draw_circle(pos, BALL_R + 10.0 + sin(time * 5.0) * 2.0, Color(glow.r, glow.g, glow.b, glow.a * 0.45))
	if double_t > 0.0:
		draw_circle(pos, BALL_R + 7.0, Color(1, 0.9, 0.3, 0.30))
	if shield:
		draw_arc(pos, BALL_R + 12.0, 0, TAU, 40, Color(0.5, 1, 0.85, 0.75), 3.0, true)

	draw_circle(pos, BALL_R, main)
	draw_circle(pos - Vector2(BALL_R * 0.28, BALL_R * 0.3), BALL_R * 0.42, main.lightened(0.22))
	draw_arc(pos, BALL_R, 0, TAU, 42, line, 2.5, true)

	# швы мяча, вращаются
	var rot := ball_spin
	draw_arc(pos, BALL_R, rot, rot + PI, 22, line, 2.5, true)
	for k in 2:
		var a := rot + PI * 0.5 * k
		var pts := PackedVector2Array()
		for i in range(15):
			var f: float = float(i) / 14.0 * PI - PI * 0.5
			var local := Vector2(sin(f) * BALL_R, cos(f) * BALL_R * 0.42 * (1 if k == 0 else -1))
			pts.append(pos + local.rotated(a))
		draw_polyline(pts, line, 2.2, true)


func _draw_particles() -> void:
	for p in particles:
		var f: float = clamp(float(p["l"]) / float(p["t"]), 0.0, 1.0)
		var c: Color = p["c"]
		draw_circle(p["p"], float(p["s"]) * f, Color(c.r, c.g, c.b, c.a * f))


func _draw_floats() -> void:
	var font := ThemeDB.fallback_font
	for f in floats:
		var a: float = clamp(float(f["l"]), 0.0, 1.0)
		var c: Color = f["c"]
		draw_string(font, Vector2(f["p"]), String(f["t"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 28,
			Color(c.r, c.g, c.b, a))


# --- данные для HUD ---
func hud_state() -> Dictionary:
	return {
		"score": score, "lives": lives, "max_lives": max_lives, "combo": combo,
		"hoops": hoops_passed, "ghost": ghost_t, "slowmo": slowmo_t,
		"double": double_t, "shield": shield, "started": started,
	}
