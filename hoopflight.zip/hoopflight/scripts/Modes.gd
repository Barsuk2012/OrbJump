# Modes.gd — режимы игры и типы колец.
class_name Modes
extends RefCounted

const LIST := [
	{
		"id": "walk", "name": "Прогулка", "desc": "Расслабленный полёт. Огня нет, жизней много.",
		"speed": 190.0, "speed_gain": 2.0, "speed_max": 300.0,
		"spacing": 520.0, "spacing_min": 420.0,
		"gate": 86.0, "gate_min": 70.0,
		"gravity": 1250.0, "jump": -470.0,
		"fire_chance": 0.0, "lives": 9,
		"tint": Color(0.55, 0.80, 0.95), "music": "calm",
	},
	{
		"id": "normal", "name": "Нормальный", "desc": "Базовая сложность. Так задумано.",
		"speed": 265.0, "speed_gain": 5.0, "speed_max": 620.0,
		"spacing": 430.0, "spacing_min": 265.0,
		"gate": 64.0, "gate_min": 40.0,
		"gravity": 1500.0, "jump": -520.0,
		"fire_chance": 0.12, "lives": 3,
		"tint": Color(0.42, 0.68, 0.92), "music": "normal",
	},
	{
		"id": "hard", "name": "Сложный", "desc": "Быстрее и огня больше.",
		"speed": 330.0, "speed_gain": 6.0, "speed_max": 700.0,
		"spacing": 380.0, "spacing_min": 240.0,
		"gate": 56.0, "gate_min": 36.0,
		"gravity": 1600.0, "jump": -535.0,
		"fire_chance": 0.22, "lives": 3,
		"tint": Color(0.85, 0.55, 0.35), "music": "normal",
	},
	{
		"id": "veryhard", "name": "Очень сложный", "desc": "Узкие коридоры, плотный поток колец.",
		"speed": 390.0, "speed_gain": 7.0, "speed_max": 760.0,
		"spacing": 345.0, "spacing_min": 225.0,
		"gate": 48.0, "gate_min": 32.0,
		"gravity": 1700.0, "jump": -550.0,
		"fire_chance": 0.32, "lives": 3,
		"tint": Color(0.75, 0.35, 0.45), "music": "tense",
	},
	{
		"id": "hardcore", "name": "Хардкор", "desc": "Две жизни. Ошибаться почти нельзя.",
		"speed": 445.0, "speed_gain": 8.0, "speed_max": 820.0,
		"spacing": 310.0, "spacing_min": 210.0,
		"gate": 42.0, "gate_min": 30.0,
		"gravity": 1800.0, "jump": -565.0,
		"fire_chance": 0.45, "lives": 2,
		"tint": Color(0.45, 0.18, 0.30), "music": "tense",
	},
	{
		"id": "ultra", "name": "Ультра Хардкор", "desc": "Все кольца горят. 25 подряд — легендарный мяч.",
		"speed": 485.0, "speed_gain": 9.0, "speed_max": 900.0,
		"spacing": 305.0, "spacing_min": 205.0,
		"gate": 40.0, "gate_min": 28.0,
		"gravity": 1850.0, "jump": -575.0,
		"fire_chance": 1.0, "lives": 1,
		"tint": Color(0.20, 0.08, 0.22), "music": "ultra",
	},
]


static func by_id(id: String) -> Dictionary:
	for m in LIST:
		if m["id"] == id:
			return m
	return LIST[1]


# --- типы колец ---
const RING_TYPES := {
	"common":   {"name": "Обычное",     "points": 5,   "color": Color(0.72, 0.74, 0.78), "glow": Color(0.9, 0.9, 0.95, 0.15)},
	"rare":     {"name": "Редкое",      "points": 10,  "color": Color(0.30, 0.60, 1.00), "glow": Color(0.3, 0.6, 1.0, 0.45)},
	"epic":     {"name": "Эпическое",   "points": 50,  "color": Color(0.70, 0.35, 1.00), "glow": Color(0.7, 0.35, 1.0, 0.55)},
	"legendary":{"name": "Легендарное", "points": 200, "color": Color(1.00, 0.80, 0.20), "glow": Color(1.0, 0.8, 0.2, 0.65)},
	"divine":   {"name": "Божественное","points": 500, "color": Color(1.00, 1.00, 1.00), "glow": Color(1.0, 1.0, 1.0, 0.85)},
}

const DIVINE_CHANCE := 0.012     # независимый шанс на каждое кольцо
const RARE_EVERY := 10
const EPIC_EVERY := 25
const LEG_EVERY := 100
