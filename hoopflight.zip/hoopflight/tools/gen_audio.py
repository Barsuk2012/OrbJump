"""
gen_audio.py — генерирует все звуки и музыку игры Hoop Flight.
Внешних аудиофайлов нет: всё синтезируется математикой.

Запуск:  python3 tools/gen_audio.py
Результат: файлы .wav в папке audio/
"""
import math
import os
import struct
import wave

import numpy as np

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "audio")


def write_wav(name, samples, stereo=False, rate=SR):
    os.makedirs(OUT, exist_ok=True)
    if rate != SR:                      # простая децимация (музыке хватает 22 кГц)
        factor = int(round(SR / rate))
        samples = samples[::factor]
    data = np.clip(samples, -1.0, 1.0)
    pcm = (data * 32000).astype("<i2")
    path = os.path.join(OUT, name)
    with wave.open(path, "wb") as w:
        w.setnchannels(2 if stereo else 1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.tobytes())
    print("  ", name, f"{os.path.getsize(path)/1024:.0f} KB")


def t(dur):
    return np.linspace(0, dur, int(SR * dur), endpoint=False)


def env(n, attack=0.005, decay=0.2, sustain=0.0, release=0.1):
    a = int(SR * attack); d = int(SR * decay); r = int(SR * release)
    s = max(n - a - d - r, 0)
    parts = [
        np.linspace(0, 1, a, endpoint=False),
        np.linspace(1, sustain, d, endpoint=False),
        np.full(s, sustain),
        np.linspace(sustain, 0, r, endpoint=False),
    ]
    out = np.concatenate(parts)
    return np.pad(out, (0, max(0, n - len(out))))[:n]


def sine(freq, dur, phase=0.0):
    return np.sin(2 * np.pi * freq * t(dur) + phase)


def sweep(f0, f1, dur, kind="sine"):
    x = t(dur)
    k = np.linspace(f0, f1, len(x))
    ph = 2 * np.pi * np.cumsum(k) / SR
    if kind == "square":
        return np.sign(np.sin(ph))
    if kind == "saw":
        return 2 * (ph / (2 * np.pi) % 1.0) - 1
    return np.sin(ph)


def noise(dur):
    return np.random.uniform(-1, 1, int(SR * dur))


def lowpass(x, cutoff):
    # простой однополюсный фильтр
    a = math.exp(-2 * math.pi * cutoff / SR)
    y = np.zeros_like(x)
    prev = 0.0
    for i in range(len(x)):
        prev = (1 - a) * x[i] + a * prev
        y[i] = prev
    return y


def bell(freq, dur, harmonics=(1, 2.01, 2.98, 4.2), amps=(1, 0.5, 0.3, 0.15)):
    out = np.zeros(int(SR * dur))
    for h, a in zip(harmonics, amps):
        out += a * sine(freq * h, dur) * env(len(out), 0.002, dur * 0.9, 0.0, dur * 0.1)
    return out / max(np.max(np.abs(out)), 1e-6)


# ---------------- эффекты ----------------

def sfx_flap():
    d = 0.16
    body = sweep(220, 520, d) * 0.5
    air = lowpass(noise(d), 2500) * 0.35
    return (body + air) * env(int(SR * d), 0.004, 0.05, 0.25, 0.09)


def sfx_ring(freq, dur=0.5, sparkle=0):
    out = bell(freq, dur) * 0.7
    swish = lowpass(noise(0.18), 4000) * 0.25
    out[: len(swish)] += swish * env(len(swish), 0.003, 0.06, 0.2, 0.1)
    for i in range(sparkle):
        f = freq * (2 + i * 0.7)
        seg = bell(f, dur * 0.5) * (0.22 - i * 0.03)
        start = int(SR * (0.06 + i * 0.05))
        out[start:start + len(seg)] += seg[: len(out) - start]
    return out / max(np.max(np.abs(out)), 1e-6) * 0.9


def sfx_fire():
    d = 0.6
    n = lowpass(noise(d), 1400) * 0.8
    crackle = np.zeros(int(SR * d))
    for _ in range(28):
        i = np.random.randint(0, len(crackle) - 400)
        crackle[i:i + 400] += np.random.uniform(0.2, 0.7) * noise(400 / SR) * env(400, 0.001, 0.004, 0, 0.004)
    return (n + crackle) * env(int(SR * d), 0.02, 0.25, 0.35, 0.3) * 0.8


def sfx_burn():
    d = 0.7
    hiss = lowpass(noise(d), 900) * 0.7
    drop = sweep(600, 90, d, "saw") * 0.35
    return (hiss + drop) * env(int(SR * d), 0.005, 0.3, 0.25, 0.35)


def sfx_hurt():
    d = 0.45
    return (sweep(420, 110, d, "square") * 0.35 + sweep(210, 60, d) * 0.4) * env(int(SR * d), 0.004, 0.2, 0.15, 0.2)


def sfx_gameover():
    notes = [(392, 0.22), (330, 0.22), (262, 0.28), (196, 0.6)]
    out = np.array([])
    for f, d in notes:
        seg = (sine(f, d) * 0.5 + sine(f * 2, d) * 0.2 + sweep(f, f * 0.98, d, "saw") * 0.15)
        out = np.concatenate([out, seg * env(len(seg), 0.01, d * 0.7, 0.15, d * 0.28)])
    return out * 0.85


def sfx_buff():
    notes = [523, 659, 784, 1047]
    out = np.zeros(int(SR * 0.55))
    for i, f in enumerate(notes):
        seg = bell(f, 0.3) * 0.5
        s = int(SR * i * 0.06)
        out[s:s + len(seg)] += seg[: len(out) - s]
    return out


def sfx_achieve():
    notes = [(523, 0.14), (659, 0.14), (784, 0.14), (1047, 0.45)]
    out = np.array([])
    for f, d in notes:
        seg = (sine(f, d) * 0.45 + sine(f * 2, d) * 0.18 + sine(f * 3, d) * 0.08)
        out = np.concatenate([out, seg * env(len(seg), 0.006, d * 0.6, 0.3, d * 0.35)])
    return out * 0.9


def sfx_click():
    d = 0.07
    return (sine(880, d) * 0.5 + sine(1320, d) * 0.2) * env(int(SR * d), 0.002, 0.03, 0.1, 0.03)


def sfx_buy():
    out = np.zeros(int(SR * 0.5))
    for i, f in enumerate([784, 1047, 1319]):
        seg = bell(f, 0.35) * 0.55
        s = int(SR * i * 0.07)
        out[s:s + len(seg)] += seg[: len(out) - s]
    return out


# ---------------- музыка ----------------

NOTE = {n: 440.0 * 2 ** ((i - 9) / 12) for i, n in enumerate(
    ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"])}


def hz(name, octave=4):
    return NOTE[name] * (2 ** (octave - 4))


def pluck(freq, dur, amp=0.3, kind="sine"):
    x = t(dur)
    if kind == "square":
        w = np.sign(np.sin(2 * np.pi * freq * x)) * 0.4 + np.sin(2 * np.pi * freq * x) * 0.6
    elif kind == "saw":
        w = 2 * ((freq * x) % 1.0) - 1
    else:
        w = np.sin(2 * np.pi * freq * x) + 0.3 * np.sin(4 * np.pi * freq * x)
    return w * env(len(x), 0.006, dur * 0.55, 0.18, dur * 0.4) * amp


def kick(dur=0.18, amp=0.5):
    return sweep(150, 45, dur) * env(int(SR * dur), 0.002, 0.08, 0.1, 0.09) * amp


def hat(dur=0.05, amp=0.16):
    return lowpass(noise(dur), 9000) * env(int(SR * dur), 0.001, 0.02, 0.05, 0.03) * amp


def build_track(bpm, bars, chords, melody_octave, wave_kind, drums, pad=True):
    beat = 60.0 / bpm
    step = beat / 2                      # восьмые
    total = int(SR * beat * 4 * bars)
    buf = np.zeros(total + SR)

    def put(sig, at):
        i = int(SR * at)
        end = min(i + len(sig), len(buf))
        buf[i:end] += sig[: end - i]

    scale = ["C", "D", "D#", "F", "G", "G#", "A#"]
    for bar in range(bars):
        root, third, fifth = chords[bar % len(chords)]
        bar_at = bar * 4 * beat
        if pad:
            d = beat * 4
            for nm, oc, a in [(root, 3, 0.16), (third, 3, 0.11), (fifth, 3, 0.09)]:
                x = t(d)
                w = np.sin(2 * np.pi * hz(nm, oc) * x) * a
                put(w * env(len(x), 0.35, d * 0.4, 0.7, d * 0.25), bar_at)
        for s in range(8):
            at = bar_at + s * step
            if drums:
                if s in (0, 4):
                    put(kick(), at)
                if s % 2 == 1:
                    put(hat(), at)
            if np.random.random() < 0.72:
                nm = scale[np.random.randint(0, len(scale))]
                oc = melody_octave + (1 if np.random.random() < 0.22 else 0)
                put(pluck(hz(nm, oc), step * 1.6, 0.22, wave_kind), at)
        put(pluck(hz(root, 2), beat * 2, 0.3, "saw"), bar_at)
        put(pluck(hz(fifth, 2), beat * 2, 0.22, "saw"), bar_at + beat * 2)

    out = buf[:total]
    # мягкое затухание в конце для бесшовной петли
    fade = int(SR * 0.08)
    out[:fade] *= np.linspace(0, 1, fade)
    out[-fade:] *= np.linspace(1, 0, fade)
    return out / max(np.max(np.abs(out)), 1e-6) * 0.75


def main():
    np.random.seed(7)
    print("Генерирую эффекты...")
    write_wav("flap.wav", sfx_flap())
    write_wav("ring_common.wav", sfx_ring(660, 0.35))
    write_wav("ring_rare.wav", sfx_ring(880, 0.45, 1))
    write_wav("ring_epic.wav", sfx_ring(1046, 0.6, 2))
    write_wav("ring_legendary.wav", sfx_ring(1318, 0.8, 3))
    write_wav("ring_divine.wav", sfx_ring(1568, 1.1, 4))
    write_wav("fire.wav", sfx_fire())
    write_wav("burn.wav", sfx_burn())
    write_wav("hurt.wav", sfx_hurt())
    write_wav("gameover.wav", sfx_gameover())
    write_wav("buff.wav", sfx_buff())
    write_wav("achieve.wav", sfx_achieve())
    write_wav("click.wav", sfx_click())
    write_wav("buy.wav", sfx_buy())

    print("Генерирую музыку...")
    calm = [("C", "E", "G"), ("A", "C", "E"), ("F", "A", "C"), ("G", "B", "D")]
    tense = [("C", "D#", "G"), ("G#", "C", "D#"), ("A#", "D", "F"), ("F", "G#", "C")]
    write_wav("music_calm.wav", build_track(76, 8, calm, 4, "sine", False), rate=22050)
    write_wav("music_normal.wav", build_track(104, 8, calm, 5, "square", True), rate=22050)
    write_wav("music_tense.wav", build_track(132, 8, tense, 5, "saw", True), rate=22050)
    write_wav("music_ultra.wav", build_track(152, 8, tense, 5, "square", True), rate=22050)
    print("Готово.")


if __name__ == "__main__":
    main()
